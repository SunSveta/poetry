# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['super']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['do_something = qwe:hello']}

setup_kwargs = {
    'name': 'super',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'yanochkina_sl',
    'author_email': 'yanochkinasvetlana@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
